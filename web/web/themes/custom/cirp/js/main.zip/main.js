/**
 * @file
 * Bootstrap-Cirp behaviors.
 */

(function ($, Drupal) {

  'use strict';

  /**
   * Behavior description.
   */
  Drupal.behaviors.bootstrapCirp = {
    attach: function (context, settings) {

     $(document).ready(function(){
        // Add minus icon for collapse element which is open by default
        $(".collapse.show").each(function(){
        	$(this).prev(".custom-header").find(".fa").addClass("fa-minus").removeClass("fa-plus");
        });

        // Toggle plus minus icon on show hide of collapse element
        $(".collapse").on('show.bs.collapse', function(){
        	$(this).prev(".custom-header").find(".fa").removeClass("fa-plus").addClass("fa-minus");
        	$(this).prev(".custom-header").parent().removeClass("nobg-color").addClass("bg-color");
        }).on('hide.bs.collapse', function(){
          $(this).prev(".custom-header").find(".fa").removeClass("fa-minus").addClass("fa-plus");
        	$(this).prev(".custom-header").parent().removeClass("bg-color").addClass("nobg-color");
        });
        // Creating Svg
          addSVG();
          console.log('init');
          var observer = new MutationObserver(addSVG);
       observer.observe(document, { childList: true, subtree: true });

       var scrolltotop = document.getElementById("go-to-top");
       $('.sidebar .block-menu.navigation .dropdown-toggle').append('<span class="fa fa-2x font-weight-bold  text-primary fa-angle-right custom-toggle"></span>');

       $('.active > span').removeClass('fa-angle-right').addClass('fa-angle-down');
       $('.active + .parent-nav').addClass('d-flex');

       $('.custom-toggle').click(function (e) {
         e.preventDefault();
         $('.custom-toggle').removeClass('fa-angle-down').addClass('fa-angle-right');
         $(this).removeClass('fa-angle-right').addClass('fa-angle-down');
         $('.sidebar .parent-nav').removeClass('d-flex');
         //$('.child-link + .parent-nav').next().hide();
         $(this).parent().next().addClass('d-flex');
       })

       $('#expandbuttons').click(function () {
        $('.reports .panel-collapses ').addClass('show');
      });
      $('#collapsebuttons').click(function () {
        $('.reports .panel-collapses ').removeClass('show');
      });
      $('#expandbutton').click(function () {
        $('.reports .panel-collapse ').addClass('show');
      });
      $('#collapsebutton').click(function () {
        $('.reports .panel-collapse ').removeClass('show');
      });

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 500 || document.documentElement.scrollTop > 500) {
    scrolltotop.style.display = "block";
  } else {
    scrolltotop.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
       $('#go-to-top').click(function(){
          document.documentElement.scrollTop = 0;
        })

        $( "#collapsebutton" ).hide();
        $( "#expandbutton" ).click(function() {
        $('div.panel-collapse').addClass('in').css("height", "");
        $('i.fa').removeClass('fa-plus').addClass('fa-minus');
        $( "#expandbutton" ).hide();
        $( "#collapsebutton" ).show();
        });
        $( "#collapsebutton" ).click(function() {
        $('div.panel-collapse').removeClass('in');
         $('i.fa').removeClass('fa-minus').addClass('fa-plus');
        $( "#expandbutton" ).show();
        $( "#collapsebutton" ).hide();
        });
        $( "div.panel a" ).click(function() {
          $('div.panel-collapse').each(function( index ) {
           if($( this ).hasClass('in') ){
           $( "#expandbutton" ).show();
            $( "#collapsebutton" ).hide();
            }
         });
        });
        //accordion
        $( "#collapsebuttons" ).hide();
        $( "#expandbuttons" ).click(function() {
        $('div.panel-collapses').addClass('in').css("height", "");
        $('span.fa').removeClass('fa-plus').addClass('fa-minus');
        $( "#expandbuttons").hide();
        $( "#collapsebuttons").show();
        });
        $( "#collapsebuttons" ).click(function() {
        $('div.panel-collapses').removeClass('in');
        $('span.fa').removeClass('fa-minus').addClass('fa-plus');
        $( "#expandbuttons" ).show();
        $( "#collapsebuttons" ).hide();
        });
        $( "div.panel a" ).click(function() {
          $('div.panel-collapses').each(function( index ) {
            if($( this ).hasClass('in') ){
            $( "#expandbuttons").show();
            $( "#collapsebuttons").hide();
            }
          });
        });

    });
  // Creating Svg function
      function addSVG() {
        console.log('123');
        $.each($('[class^="svg-"]'), function( key, value ) {
          var oldCls = $(value).attr("class");
          var cls = $("#"+oldCls.slice(4, (oldCls.indexOf(' ')<0) ? oldCls.length : oldCls.indexOf(' ')));
          $(value).append(cls.parent().clone())
            .css({ "width": cls.attr("width"), "height": cls.attr("height") });
          $(this).attr("class", $(this).attr("class").replace("svg-", "svgd-"));
        });
      }




    }
  };

} (jQuery, Drupal));
